import pandas as pd
import re
import os
import argparse
from openai import OpenAI
from sklearn.metrics import classification_report

### Connect to local LLaMA server
client = OpenAI(
    base_url="http://localhost:8000/v1",
    api_key="not-needed"
)

def query_LLM(model_client, prompt, temp=0):
    history = [{"role": "user", "content": prompt}]
    completion = model_client.chat.completions.create(
        model="local-model",
        messages=history,
        temperature=temp,
        stream=False,
    )
    return completion.choices[0].message.content

### Pool of few-shot examples
EXAMPLES_ALL = [
    # EXP
    ("EXP", "@USER you are a lying corrupt traitor!!! Nobody wants to hear anymore of your lies!!! #DeepStateCorruption URL"), #TIN/IND
    ("EXP", "@USER “the sex symbol of rap” LMAOOO BITCH YOUre  FAT aS FUCK ANYWAYS you tryna fight?"), #TIN/GRP
    ("EXP", "MAGA are PERVERTS AND DEMONS-PERIOD! NOTHING IS SACRED OR INNOCENT WITH THESE MUTTS OF SATAN URL"), #TIN/OTH
    ("EXP", "@USER What the fuck game are you watching?"), #UNT
    ("EXP", "@USER If you go by anything other than he or she you are fucked in the head."), #TIN/IND
    ("EXP", "@USER @USER The FASCISTS are Anti-American Communist Scum like yourself!! Now go Fuck Yourself you piece of human garbage!! USA #MAGA  ANTIFA are Terrorists"), #TIN/GRP
    ("EXP", "@USER @USER Are you bipolar? You keep saying different shit to people commenting on what u said"), #TIN/OTH
    ("EXP", "@USER So what ur saying is that it is in fact chicken shit and you are eating chicken shit URL"), #UNT

    # IMP
    ("IMP", "@USER Gun Control means using both hands. And in this case means acquiring the correct target. You can’t fix stupid."), #UNT
    ("IMP", "10kids from different women from this American jobless men? Nigerian men you are the bomb!!!"),  #TIN/OTH
    ("IMP", "4 out of 10 British people are basically full-on racists. 4 out of 10 voters vote for the Conservatives. Coincidence!???!???"),  #TIN/GRP
    ("IMP", "@USER       Thank you for your fortitude and perseverance. Please give McConnell a kick in the butt from some of us conservatives."),  #TIN/IND
    ("IMP", "2 hours at midnight and she said she is not a call girl?  -Awkward!"), #UNT
    ("IMP", "@USER Do you think she is afraid of pigs that are not the same colour as her? 😊"), #TIN/OTH
    ("IMP", "@USER Love how fat they all are while chowing down on cake and cookies. That's the future liberals want."), #TIN/GRP
    ("IMP", "@USER Absolutely should be a nail in the coffin.... for Hillary"), #TIN/IND

    # NOTABU
    ("NOTABU", "@USER What if knowing that abortion is at stake in November mobilizes pro life forces? Kavanaugh being denied makes it critical for conservatives to maintain the Senate. Because most (R) seats are not up for election it could be a blessing."),
    ("NOTABU", "(You are! My prayer is that you are blessed with someone you know like that also. Someone who feels your basic human rights are worth protecting. Especially your God given right to personal privacy.)"),
    ("NOTABU", "@USER You should reach out to Paul.berger@USER He is teaching & researching these classes. & he is fierce & great! V. Ethical."),
    ("NOTABU", "@USER You guys have featured splendidrainco's etsy page and she is being censored by etsy now. You can't find her site through the search engine you have to have a direct link. And according to her instagram post they have been basically leaving her out to dry."),
    ("NOTABU", "@USER Aww Bradley you are so cute"),
    ("NOTABU", "@USER So happy for you and your dad!!! My dad had the same kind of cancer but stage 4. He was diagnosed in 2016 and passed away this passed January. My mom is kicking leukemia’s ass since Nov. of 2015 and she is doing awesome!"),
    ("NOTABU", "@USER @USER It's OK that you are confused. Paul Guenther is a proven DC and play caller. We are rebuilding and trying to remain competitive at the same time. We will have steady improvement"),
    ("NOTABU", "@USER I loved the House Bunny. And the remembering names voice was funny. My family and I watch Mom it’s great. I’m a recovered addict or moderately recovered if you are one who counts pot lol. It’s a very good show.")
]

### REASONING 
REASONING_BASE = [
    # EXP 8
    "This message attacks a person directly using insults and strong anger.",
    "This message includes profanity, body shaming, and a threat. It is rude and aggressive.",
    "This message uses extreme insults to attack a political movement. It is hateful and hostile.",
    "This message asks a question in a disrespectful way and includes profanity.",
    "This message attacks people for their gender identity using profanity. It's demeaning.",
    "This message is extremely aggressive and dehumanizing. It includes personal and political attacks.",
    "This message insults someone by implying a mental health condition in a mocking way. It uses profanity and is demeaning.",
    "This message uses crude language to describe what someone is saying. It's vulgar, insulting, and disrespectful.",

    # IMP 8
    "This message suggests violence and ends with an insult.",
    "This message mocks Nigerian men using stereotypes and sarcasm. It is insulting and racist.",
    "This message links a group to racism with a harmful stereotype and ends with a suggestive question. It is offensive.",
    "This message suggests physical aggression against someone. Even if partly joking, it is still hostile.",
    "This message implies a degrading assumption through a mocking question. It's suggestive and disrespectful.",
    "This message implies a racial insult in a sarcastic tone and compares someone to animals.",
    "This message insults a political group through body shaming and sarcasm. It's demeaning and indirectly hostile.",
    "This message uses a metaphor associated with death to refer to a political figure. It is ominous and implicitly threatening.",

    # NOTABU 8
    "This message shares a political opinion without insults or hate.",
    "This message includes wishes and prayers. It is kind and respectful toward someone.",
    "This message gives a helpful suggestion and ends by praising the suggested teacher.",
    "This message expresses light frustration about how someone is treated but remains respectful.",
    "This message is a simple, kind compliment.",
    "This message shows support and tells a personal story about the health of family members.",
    "This message shares a sports opinion in an affirming and supportive way.",
    "This message talks about TV shows in a light and personal way.",
]

### REASONING TARGET
REASONING_TARGET = [
    # EXP 8
    "This message targets an individual directly using insults and strong anger.",
    "This message includes body shaming that is targeted toward a group.",
    "This message uses extreme insults to target a political movement.",
    "This message asks a question in a disrespectful way and includes profanity, but remains untargeted.",
    "This message targets an individual by attacking their gender identity using profanity.",
    "This message uses personal and political insults to target a group.",
    "This message targets people with a mental illness in a mocking and disrespectful way.",
    "This message uses vulgar language to insult someone, but it remains untargeted.",

    # IMP 8
    "This message suggests violence and ends with an insult, but it is not directly targeted.",
    "This message targets Nigerian men using stereotypes and sarcasm.",
    "This message targets a group by linking it to racism through a harmful stereotype and a suggestive question.",
    "This message suggests physical aggression targeted at an individual.",
    "This message implies a degrading assumption through a mocking question, but remains untargeted.",
    "This message implies a racial insult in a sarcastic way, targeting people based on skin color.",
    "This message targets a political group through body shaming and sarcasm.",
    "This message suggests harm toward an individual through a metaphor associated with death.",

    # NOTABU 8
    "This message shares a political opinion without any target.",
    "This message includes wishes and prayers. It is kind and respectful toward someone, but not targeted.",
    "This message gives a helpful suggestion and ends by praising the suggested teacher, but remains untargeted.",
    "This message expresses light frustration about how someone is treated but remains untargeted.",
    "This message is a simple, kind compliment and stays untargeted.",
    "This message shows support and tells a personal story about the health of family members. It does not include a target.",
    "This message shares a sports opinion in an affirming and supportive way without a target.",
    "This message talks about TV shows in a light and personal way without a target.",
]

### REASONING IHC

REASONING_IHC = [
    # EXP 8
    "This message attacks a person directly using insults and strong anger. It includes threats and intimidation.",
    "This message includes profanity, body shaming, and a threat. It includes inferiority language and intimidation.",
    "This message uses extreme insults to attack a political movement. It includes threats and dehumanizing language.",
    "This message asks a question in a disrespectful way and includes profanity. It includes irony and mild intimidation.",
    "This message attacks people for their gender identity using profanity. It includes inferiority language and intimidation.",
    "This message is extremely aggressive and dehumanizing. It includes threats, intimidation, and hate toward a political movement.",
    "This message uses profanity and mocks a mental health condition to insult someone. It includes inferiority language and is directly demeaning.",
    "This message uses vulgar and dehumanizing language to insult someone in a crude way. It shows strong disrespect but is not directly threatening.",

    # IMP 8
    "This message suggests violence and ends with an insult. It includes incitement to violence and irony.",
    "This message mocks Nigerian men using stereotypes and sarcasm. It includes stereotypes and misinformation.",
    "This message links a group to racism with a harmful stereotype and ends with a suggestive question. It includes stereotypes and misinformation.",
    "This message suggests physical aggression against someone. Even if partly joking, it includes incitement to violence.",
    "This message implies a degrading assumption through a mocking question. It includes irony and inferiority language.",
    "This message implies a racial insult in a sarcastic tone and compares someone to animals. It includes stereotypes and inferiority language.",
    "This message uses body shaming and sarcasm to insult a political group. It includes irony and inferiority language.",
    "This message uses a metaphor associated with death to suggest harm toward political figure. It implies incitement to violence and includes threats and intimidation.",

    # NOTABU 8
    "This message shares a political opinion without insults or hate. It does not include any harmful framing.",
    "This message includes wishes and prayers. It is kind and respectful toward someone. It does not include threats, stereotypes, or other harmful speech.",
    "This message gives a helpful suggestion and ends by praising the suggested teacher. It does not include any harmful content.",
    "This message expresses light frustration about how someone is treated but remains respectful. It does not include stereotypes or insults.",
    "This message is a simple, kind compliment. It contains no negativity or bias.",
    "This message shows support and tells a personal story about the health of family members. It is empathetic and non-hostile.",
    "This message shares a sports opinion in an affirming and supportive way. It does not target or insult anyone.",
    "This message talks about TV shows in a light and personal way. It does not include stereotypes or aggressive tone.",
]

### Prompt

def build_prompt(setup, batch, mode="standard"):
    n = len(batch)
    assert n > 0, "Batch cannot be empty."
    assert mode in {"standard", "targeted", "IHC_labels"}, "Mode must be one of: standard, targeted, IHC_labels"

    numbered_tweets = "\n".join([f"{j+1}. {t}" for j, t in enumerate(batch)])

    if mode == "standard":
        base = """Classify the following texts into one of the following categories:
- explicit abuse (EXP)
- implicit abuse (IMP)
- not abusive (NOTABU)

Instructions for each text:
1. Write 1–2 short sentences explaining why the text is classified as EXP or IMP or NOTABU.
2. Then output the label on a separate line starting with: Label: EXP or Label: IMP or Label: NOTABU.

Follow this example format:
Reasoning: <reasoning>
Label: <EXP or IMP or NOTABU>
"""
    elif mode == "targeted":
        base = """Classify the following texts into one of the following categories:
- explicit abuse (EXP)
- implicit abuse (IMP)
- not abusive (NOTABU)

Instructions for each text:
1. Write 1–2 short sentences explaining why the text is classified as EXP or IMP or NOTABU. Consider in your explanation if the text is targeted or untargeted.
2. Then output the label on a separate line starting with: Label: EXP or Label: IMP or Label: NOTABU.

Follow this example format:
Reasoning: <reasoning>
Label: <EXP or IMP or NOTABU>
"""
    else:  # mode == "IHC_labels"
        base = """Classify the following texts into one of the following categories:
- explicit abuse (EXP)
- implicit abuse (IMP)
- not abusive (NOTABU)

Instructions for each text:
1. Write 1–2 short sentences explaining why the text is classified as EXP or IMP or NOTABU. Consider if the text includes:
- white grievance
- incitement to violence
- inferiority language
- irony
- stereotypes and misinformation
- threatening and intimidation
2. Then output the label on a separate line starting with: Label: EXP or Label: IMP or Label: NOTABU.

Follow this example format:
Reasoning: <reasoning>
Label: <EXP or IMP or NOTABU>
"""

    shots = {
        "P1": 0,
        "P2": 1,
        "P3": 6,
        "P4": 8,
    }.get(setup, 0)

    if shots > 0:
        exp_examples = [ex for ex in EXAMPLES_ALL if ex[0] == "EXP"][:shots]
        imp_examples = [ex for ex in EXAMPLES_ALL if ex[0] == "IMP"][:shots]
        notabu_examples = [ex for ex in EXAMPLES_ALL if ex[0] == "NOTABU"][:shots]

        example_lines = []

        for i in range(shots):
            label, text = exp_examples[i]
            reasoning = REASONING_BASE[i] if mode == "standard" else \
                        REASONING_TARGET[i] if mode == "targeted" else \
                        REASONING_IHC[i]
            example_lines.append(f"Text: {text}\nReasoning: {reasoning}\nLabel: {label}")

        for i in range(shots):
            label, text = imp_examples[i]
            offset = 8  # IMP starts at index 8
            reasoning = REASONING_BASE[i + offset] if mode == "standard" else \
                        REASONING_TARGET[i + offset] if mode == "targeted" else \
                        REASONING_IHC[i + offset]
            example_lines.append(f"Text: {text}\nReasoning: {reasoning}\nLabel: {label}")

        for i in range(shots):
            label, text = notabu_examples[i]
            offset = 16  # NOTABU starts at index 16
            reasoning = REASONING_BASE[i + offset] if mode == "standard" else \
                        REASONING_TARGET[i + offset] if mode == "targeted" else \
                        REASONING_IHC[i + offset]
            example_lines.append(f"Text: {text}\nReasoning: {reasoning}\nLabel: {label}")

        base += "\nHere are a few examples of labeled texts:\n" + "\n".join(example_lines)
        base += "\n\n"
    else:
        base += "\n"

    base += f"""Now classify the following texts. ALWAYS output the instruction steps for EACH of the {n} texts.

Texts:
{numbered_tweets}
"""

    return base

def extract_labels_fallback(text, expected_count):
    lines = text.strip().splitlines()
    labels = []
    for line in lines:
        match = re.search(r"Label\s*[:\-]?\s*(EXP|IMP|NOTABU)", line, re.IGNORECASE)
        if match:
            labels.append(match.group(1).upper())
    return labels if len(labels) == expected_count else None

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--setup", choices=["P1", "P2", "P3", "P4"], required=True, help="Setup (P1–P4)")
    parser.add_argument("--temperature", type=float, default=0.0, help="Sampling temperature for the model (default: 0.0)")
    parser.add_argument("--mode", choices=["standard", "targeted", "IHC_labels"], default="standard", help="Prompt mode")
    args = parser.parse_args()
    setup = args.setup
    temperature = args.temperature

    # Load test data
    df = pd.read_csv("data/test/OLID_AbuseEval_test.tsv", sep="\t")
    tweets = df["tweet"].tolist()
    print(f"▶ Running ternary setup {setup} on {len(tweets)} tweets...")

    predictions = []
    batch_size = 3

    for i in range(0, len(tweets), batch_size):
        batch = tweets[i:i+batch_size]
        prompt = build_prompt(setup, batch, mode=args.mode)

        try:
            result = query_LLM(client, prompt, temp=temperature)
            print(f"\n=== MODEL OUTPUT ({i}) ===\n{result}\n")
            labels = extract_labels_fallback(result, len(batch))
            if labels:
                predictions.extend(labels)
            else:
                print(f"⚠️ Unable to parse labels from output:\n{result}")
                predictions.extend(["ERROR"] * len(batch))
        except Exception as e:
            print(f"⚠️ Error on batch {i}: {e}")
            predictions.extend(["ERROR"] * len(batch))

    df = df.iloc[:len(predictions)]
    df["prediction"] = predictions

    # Save predictions
    os.makedirs("predictions", exist_ok=True)
    pred_file = f"predictions/ternary-CoT-{args.mode}-{setup}-t{temperature:.2f}_predictions.csv"
    report_file = f"predictions/ternary-CoT-{args.mode}-{setup}-t{temperature:.2f}_report.txt"
    df.to_csv(pred_file, index=False)
    print(f"✅ Predictions saved to {pred_file}")

    # Evaluate if gold labels exist
    if "abuse" in df.columns:
        label_map = {
            "EXP": "EXP",
            "IMP": "IMP",
            "NOTABU": "NOTABU"
        }
        if not df["abuse"].isin(label_map.keys()).all():
            print("❗ Found unexpected labels in 'abuse' column!")
        else:
            df["gold_ternary"] = df["abuse"].map(label_map)
            report = classification_report(df["gold_ternary"], df["prediction"], labels=["EXP", "IMP", "NOTABU"])
            with open(report_file, "w") as f:
                f.write(report)
            print(f"📊 Report saved to {report_file}")
    else:
        print("⚠️ Column 'abuse' not found for evaluation.")

if __name__ == "__main__":
    main()
