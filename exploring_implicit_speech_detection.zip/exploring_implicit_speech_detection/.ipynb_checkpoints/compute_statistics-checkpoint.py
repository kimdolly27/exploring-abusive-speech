### Statistics of the dataset ####

import pandas as pd

# Print counts and percentages of 'abuse' classes
def print_abuse_distribution(df, label):
    """
    Print count and percentage distribution of the 'abuse' column for a given DataFrame.
    """
    total = len(df)
    abuse_counts = df['abuse'].value_counts(dropna=False)
    abuse_percentages = df['abuse'].value_counts(normalize=True, dropna=False) * 100

    distribution = pd.DataFrame({
        'Count': abuse_counts,
        'Percentage': abuse_percentages.round(2)
    })

    print(f"\nAbuse Distribution - {label}")
    print(distribution)
    print(f"Total rows: {total}")
    print("-" * 60)

# Print value counts for subtask columns
def print_distribution(df, name):
    """
    Print value counts for subtask_a, subtask_b, and subtask_c if present.
    """
    label_map = {
        'subtask_a': 'Subtask A – Offensive Language Detection',
        'subtask_b': 'Subtask B – Type of Offensive Language',
        'subtask_c': 'Subtask C – Target of Offense'
    }

    print(f"\nSubtask Distribution - {name}")
    for subtask in ['subtask_a', 'subtask_b', 'subtask_c']:
        if subtask in df.columns:
            print(f"\n{label_map[subtask]}:")
            print(df[subtask].value_counts(dropna=False))

# Print subtask_a distribution for IMP or EXP abuse only
def print_subtask_a_imp_exp(df, name):
    """
    Print value counts of subtask_a where abuse is IMP or EXP.
    """
    if {'abuse', 'subtask_a'}.issubset(df.columns):
        filtered_df = df[df['abuse'].isin(['IMP', 'EXP'])]
        print(f"\nSubtask A (IMP or EXP only) - {name}")
        print(filtered_df['subtask_a'].value_counts(dropna=False))

# File paths
hic_path = "./data/train/olid_abuseeval_hic_train.tsv"
main_path = "./data/train/olid_abuseeval_train.tsv"
test_path = "./data/test/olid_abuseeval_test.tsv"

# Load and analyze HIC file
print(f"\nLoading: {hic_path}")
df_hic = pd.read_csv(hic_path, sep='\t')
print_abuse_distribution(df_hic, "HIC File (Full)")

# Get first 5 rows starting from first id == 1
start_index_hic = df_hic.index[df_hic['id'] == 1].min()
if not pd.isna(start_index_hic):
    df_hic_from_id1 = df_hic.loc[start_index_hic:]
    print_abuse_distribution(df_hic_from_id1, "HIC File (From ID == 1)")

    print("\nFirst 5 rows from ID == 1 onward:")
    print(df_hic_from_id1.head(5))

# Load and analyze main (train) file
print(f"\nLoading: {main_path}")
train_df = pd.read_csv(main_path, sep='\t')
print_abuse_distribution(train_df, "Main (Train) File")

# Load and analyze test file
print(f"\nLoading: {test_path}")
test_df = pd.read_csv(test_path, sep='\t')
print_abuse_distribution(test_df, "Test File")

# Show sample rows
print("\nFirst rows of Main (Train) File:")
print(train_df.head())

print("\nFirst rows of Test File:")
print(test_df.head())

# Show subtask distributions
print_distribution(train_df, "Main (Train) File")
print_distribution(test_df, "Test File")